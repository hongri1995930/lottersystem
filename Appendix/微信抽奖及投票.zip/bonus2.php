<?php
function Bonus($postObj, $url){
    $fromusername = $postObj->FromUserName;
    $mysql = new SaeMysql();    
    $sql = "SELECT  * FROM  `Bonus` WHERE UserName =  '{$fromusername}'";
    $mysql->runSql($sql);
    $data = $mysql->getData( $sql );
    $line = count($data);
    if ($line > 0)
    {
        if($data[0]['Section1'] == 1 && $data[0]['Section2'] == 1)//已抽取过
        {
            $result = "每个人只有一次抽奖机会哦~";
        }
        else//未抽取过
        {
        	//完成Section1
            $sql = "Update `Bonus` set `Section1` = '1', `PicUrl` = '{$url}' where `UserName` = '{$fromusername}'";
            $mysql->runSql($sql);
            if($data[0]['Section2'] == 1){
                $num = rand(1,9).rand(1,9).rand(1,9).rand(1,9).rand(1,9);
				$sql = "Update `Bonus` set `UserCode` = '{$num}' where `UserName` = '{$fromusername}'";
				$mysql->runSql($sql);
				$result = "任务完成！\n你的国际码为<a>".$num."</a>\n中奖号码会公布在大本营，请于活动当天到大本营领取奖品~";
        	}else{
            	$result = "任务已完成50%，回复<a>投票#国家</a>支持喜欢的国家摊位，完成任务获取国际码，抽取大奖~";
        	}
        }
    }else{
        $sql = "Insert into `Bonus`(`UserName`, `Section1`, `PicUrl`) values('{$fromusername}', '1', '{$url}')";
    	$mysql->runSql($sql);
        $result = "任务已完成50%，回复<a>投票#国家</a>支持喜欢的国家摊位，完成任务获取国际码，抽取大奖~";
    }    
	if ($mysql->errno() != 0)
	{
		die("Error:" . $mysql->errmsg());
    }
	$mysql->closeDb();
    return $result;
}

function vote($postObj, $keyword){
    $fromusername = $postObj->FromUserName;
    $mysql = new SaeMysql();    
    $sql = "SELECT  * FROM  `Bonus` WHERE UserName =  '{$fromusername}'";
    $mysql->runSql($sql);
    $data = $mysql->getData( $sql );
    $line = count($data);
    if ($line > 0)
    {
        if($data[0]['Section1'] == 1 && $data[0]['Section2'] == 1)//已抽取过
        {
            $result = "每个人只有一次抽奖机会哦~";
        }
        else//未抽取过
        {
        	//完成Section2
            $sql = "Update `Bonus` set `Section2` = '1', `UserVote` = '{$keyword}' where `UserName` = '{$fromusername}'";
    		$mysql->runSql($sql);
        	if($data[0]['Section1'] == 1)
            {
            	$num = rand(1,9).rand(1,9).rand(1,9).rand(1,9).rand(1,9);
				$sql = "Update `Bonus` set `UserCode` = '{$num}' where `UserName` = '{$fromusername}'";
				$mysql->runSql($sql);
				$result = "任务完成！\n你的国际码为<a>".$num."</a>\n中奖号码会公布在大本营，请于活动当天到大本营领取奖品~";
            }else{
            	$result = "任务已完成50%，<a>分享你参与活动的露脸照片到朋友圈并截屏发送到本平台</a>，完成任务获取国际码，抽取大奖~";
        	}
        }
    }else{
        $sql = "Insert into `Bonus`(`UserName`, `Section2`, `UserVote`) values('{$fromusername}', '1', '{$keyword}')";
    	$mysql->runSql($sql);
        $result = "任务已完成50%，<a>分享你参与活动的露脸照片到朋友圈并截屏发送到本平台</a>，完成任务获取国际码，抽取大奖~";
    }
	if ($mysql->errno() != 0)
	{
		die("Error:" . $mysql->errmsg());
    }
	$mysql->closeDb();
    return $result;
}

function Shorten($url){
    $ch=curl_init();
	curl_setopt($ch,CURLOPT_URL,"http://dwz.cn/create.php");
	curl_setopt($ch,CURLOPT_POST,true);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
	$data=array('url'=>$url);
	curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
	$strRes=curl_exec($ch);
	curl_close($ch);
	$arrResponse=json_decode($strRes,true);
	return $arrResponse['tinyurl'];
}

function GetBonus($object, $UserPrize, $flag=0){
    $mysql = new SaeMysql();
    $sql = "SELECT  * FROM  `Bonus` where UserPrize = '{$UserPrize}'";
    $mysql->runSql($sql);
    $data = $mysql->getData($sql);
    $line = count($data);
    if($UserPrize == '一等奖' && $line == 1)
    {
        $content = '一等奖名额只有1个，且已抽完。';
        $textTpl = "<xml>
                    <ToUserName><![CDATA[%s]]></ToUserName>
                    <FromUserName><![CDATA[%s]]></FromUserName>
                    <CreateTime>%s</CreateTime>
                    <MsgType><![CDATA[text]]></MsgType>
                    <Content><![CDATA[%s]]></Content>
                    <FuncFlag>0</FuncFlag>
                    </xml>";
    	$resultStr = sprintf($textTpl, $object->FromUserName, $object->ToUserName, time(), $content, $flag);
    }
    elseif($UserPrize =='二等奖' && $line == 6)
    {
        $content = '二等奖名额只有4个，且已抽完。';
        $textTpl = "<xml>
                    <ToUserName><![CDATA[%s]]></ToUserName>
                    <FromUserName><![CDATA[%s]]></FromUserName>
                    <CreateTime>%s</CreateTime>
                    <MsgType><![CDATA[text]]></MsgType>
                    <Content><![CDATA[%s]]></Content>
                    <FuncFlag>0</FuncFlag>
                    </xml>";
    	$resultStr = sprintf($textTpl, $object->FromUserName, $object->ToUserName, time(), $content, $flag);
    }
    else
    {
        $sql = "SELECT  * FROM  `Bonus` where UserPrize = '' and UserCode <> '' ";
        $mysql->runSql($sql);
    	$data = $mysql->getData($sql);
    	$line1 = count($data);
        if($line1 == 0)
        {
            $content = '人数不达要求，请稍后抽取。查看参与人数请回复“结果”。';
        	$textTpl = "<xml>
                    	<ToUserName><![CDATA[%s]]></ToUserName>
                    	<FromUserName><![CDATA[%s]]></FromUserName>
                    	<CreateTime>%s</CreateTime>
                    	<MsgType><![CDATA[text]]></MsgType>
                    	<Content><![CDATA[%s]]></Content>
                    	<FuncFlag>0</FuncFlag>
                    	</xml>";
    		$resultStr = sprintf($textTpl, $object->FromUserName, $object->ToUserName, time(), $content, $flag);
        }
        else
        {
        	$sql = "SELECT  * FROM  `Bonus`";
        	$mysql->runSql($sql);
            $data = $mysql->getData($sql);
    		$line = count($data);
    		do {
    			$id = rand(1,$line);
    			$sql = "SELECT  * FROM  `Bonus` where Id = '{$id}'";
    			$mysql->runSql($sql);
    			$data = $mysql->getData($sql);
    		} while ($data[0]["UserPrize"] != null or $data[0]['UserCode'] == null);
    		$content = "恭喜你获得<a>{$UserPrize}</a>，请及时到兑奖处兑换奖品~\n兑换时请出示国际码，活动结束前未及时兑换视为弃权。";
    		$textTpl = "<xml>
                    	<ToUserName><![CDATA[%s]]></ToUserName>
                    	<FromUserName><![CDATA[%s]]></FromUserName>
                    	<CreateTime>%s</CreateTime>
                    	<MsgType><![CDATA[text]]></MsgType>
                    	<Content><![CDATA[%s]]></Content>
                    	<FuncFlag>0</FuncFlag>
                    	</xml>";
    		$resultStr = sprintf($textTpl, $data[0]['UserName'], $object->ToUserName, time(), $content, $flag);
    		$sql = "Update `Bonus` set `UserPrize` = '{$UserPrize}' where `Id` = '{$id}'";
    		$mysql->runSql($sql);
        }
    }
    $mysql->closeDb();
    return $resultStr;
}

function GetCount(){
    $mysql = new SaeMysql();
    $sql = "SELECT  * FROM  `Bonus`";
    $mysql->runSql($sql);
    $data = $mysql->getData($sql);
    $count = count($data);
    $result = "目前参与人数：<a>".$count."</a>人\n";
    $sql = "SELECT  * FROM  `Bonus` where UserPrize = '一等奖'";
    $mysql->runSql($sql);
    $data = $mysql->getData($sql);
    $result = $result."一等奖：<a>".$data[0]['UserCode']."</a>\n二等奖：";
    $sql = "SELECT  * FROM  `Bonus` where UserPrize = '二等奖'";
    $mysql->runSql($sql);
    $data = $mysql->getData($sql);
    $count = count($data);
    for($i = 0; $i < $count; $i ++){
        $result = $result.$data[$i]['UserCode']."、";
    }
    $sql = "SELECT  * FROM  `Bonus` where UserPrize = '三等奖'";
    $mysql->runSql($sql);
    $data = $mysql->getData($sql);
    $line = count($data);
    $result = $result."\n三等奖：";
    for($j = 0; $j < $line; $j ++)
    {
        $result = $result.$data[$j]['UserCode']."、";
    }
    return $result;
    $mysql->closeDb();
}

?>